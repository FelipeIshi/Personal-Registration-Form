$(document).ready(function(){
    $('#cpf').mask('000.000.000-00');
    $('#telefone').mask('(00) 0000-0000');
    $('#celular').mask('(00) 0 0000-0000');
    $('#cep').mask('00000-000');
    $('#numero').mask('00000');
    // $('#complemento').mask('CASA00');
})
