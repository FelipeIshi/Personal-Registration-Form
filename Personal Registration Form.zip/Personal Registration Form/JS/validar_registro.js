function validar_formContato(){
    var nome = formContato.nome.value;
    var cpf = formContato.cpf.value;
    var celular = formContato.celular.value;
    var cep = formContato.cep.value;
    var numero = formContato.numero.value;
    var complemento = formContato.complemento.value;

    if(nome==""){
        alert("Inserir Nome.");
        formContato.nome.focus()
        return false;
    }
    if(cpf==""){
        alert("Inserir CPF.");
        formContato.cpf.focus()
        return false;
    }
  
    if(celular==""){
        alert("Inserir Celular.");
        formContato.celular.focus()
        return false;
    }
    if(cep==""){
        alert("Inserir CEP.");
        formContato.cep.focus()
        return false;
    }
    if(numero == ""){
        alert("Inserir numero");
        formContato.numero.focus()
        return false
    }
    if(complemento == ""){
        alert("Inserir complemento");
        formContato.complemento.focus()
        return false
    }
     else{
        alert ("cadastro efetuado com sucesso....")
    }
  
}
